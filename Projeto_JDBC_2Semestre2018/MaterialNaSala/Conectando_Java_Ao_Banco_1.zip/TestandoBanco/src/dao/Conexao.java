package dao;
/*Essa classe ser� usada para manipularmos nossa conex�o com o banco de dados!
 * Nela faremos a conex�o
 * O envio de instru��es que modificam os dados de uma tabela
 * O envio de instru��es que retornam dados de uma tabela
 * */


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.Statement;

public class Conexao {
       
}
